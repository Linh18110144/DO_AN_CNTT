﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace webMVC.Areas.GiaoVien.Controllers
{
    public class LoginController : Controller
    {
        // GET: GiaoVien/Login
        public ActionResult Index()
        {
            return View();
        }
    }
}